/* esta funcion esta disenda para generar fireworks usando el sonido en tres ocaciones
una es cuando el sonido es mas fuerte mas de 185 podra soltar un firework aleatoriamente
ademas entre mas fuerte sea el sonido en una escala de 160 a 200 sera lo mas alto que podra llegar,
y por ultimo el tamano de la explocion del firework tambien dempensera de de escala de fourier.
 */
function Fire() {
	this.name = "Fire";
    this.img = loadImage('imagenes/city-sunset-digital.4.jpg')
    var fireworks = [];
    var gravity;// me ayudara a aplicar la  gravedad para hacer cael el elemento
    stroke(255);
    strokeWeight(6);
    
    gravity = createVector(0,0.2);
  
    this.draw = function() {
        background(0,25)
        fourier.analyze()
        rf = fourier.getEnergy(50,220)
        background(100)
        image(this.img,0,0,width,height)
        
        //usando en constructor para crear la primera parte del firework
        if(rf >= 185){
          fireworks.push(new Firework());  
        }
        // o si no solo crea un firwork 
        else if(random(1) < 0.01){
           fireworks.push(new Firework());   
        }
        // despues del constructor se almacena en el array usando las  propiedades
        for(var i = fireworks.length -1; i >= 0; i--){
            fireworks[i].update();
            fireworks[i].show();
            if(fireworks[i].done()){
                fireworks.splice(i, 1)
            }
        }
        
    }
    
    
// la funcion  particulas sera la asignada a la parte principal de mi firework    
function  Particles(x,y, col, fireOn) {
    this.pos = createVector(x, y);// la posicion inicial en el vector
    this.fireworks = fireOn; // un boolean  para confirmar si ya exploto
    this.liveFire = 255; //la luminosidad del firework para que desaparesca
    this.col = col;
  
    if(this.fireworks){
        // podemos contralar la velocidad de las particulas y lo alto que puden llegar 
        if(rf < 184){
            // la condicon ayuda a que los firework que se cran sin los bits no pasen la parte inferior de la pantalla
            this.vel = createVector(0, random(rf = -7 ,rf = -8));
        }else{
           this.vel = createVector(0, random(rf = -20 ,rf = -11)); 
        }
        
    }else{
        // este else con los if anidados puedo gener un tamana diferente a cada explocion // aun es de modificar 
        this.vel = p5.Vector.random2D();
        if(rf > 160 && rf <=170){
        this.vel.mult(random(12,10 ))
       }else if(rf > 171 && rf <= 180){
          this.vel.mult(random( 5, 8))  
        }else if (rf > 181 && rf < 182){
          this.vel.mult(random( 3, 30))  
       }else if(rf > 191 && rf < 220){
           this.vel.mult(random(20,18))
        }else{
           this.vel.mult(random(1))
       }
        
        
    }
        
    this.acc = createVector(0, 0);  
    // aplicar la fueza para que las particulas se separce a las direcciones opuestas 
    this.applyForce = function (force){
        this.acc.add(force)
    }
        
    this.update = function() {
        if(!this.fireworks){
            this.vel.mult(0.9)// la velocidad en la que caen el firework 
            this.liveFire -=4; // la velocidad en que explocion desaparecera en la pantalla 
        }
        this.vel.add(this.acc);
        this.pos.add(this.vel);
        this.acc.mult(0)
    }
    //cuando el livefire sera verdadero y eliminara las particulas
    this.done = function(){
        if(this.liveFire < 0){
            return true;
        }else{
            return false;
        }
    }

    this.show = function(){
        if(!this.fireworks){
            //manupular los colores y tamano  del firework despues de explotar 
            strokeWeight(3);
            // elejimos random para los dos propiedades para generar un mejor efecto de luz 
            stroke(col,random(250),random(0,255),this.liveFire+100)
        }else{
            //colores y tamano antes de explotar
            strokeWeight(4);
            stroke(col,0,200,255)
        }
        point(this.pos.x, this.pos.y)
    }
    
    }
    
// funcion que me permitira crear y modificar el explocion del firework 
function Firework() {
    this.col = random(0,255)
    this.firework = new Particles(random(width), height,this.col, true);
    this.explo = false;
    // este nuevo arry almacenara la explocion del firework 
    this.parti = [];
    // creando la funcion done puedo eliminar las particulas que ya explotaron para darle paso a las nuevas que llegara a si no se vuelve lento el programa. las dos funciones done tienee que ser verdadres para poder eliminar el firework 
    this.done = function(){
        if( this.explo && this.parti.length ===0){
             return true;
        }else{
            return false;
        }
    }
    this.update = function() {
        // crear el objeto usando las propiedades
        if(!this.explo){ //si se cumple la funcion crea la explocion y aplica tambien la fuerza con la funcion gravedad 
           this.firework.applyForce(gravity)
           this.firework.update();
           if(this.firework.vel.y >= 0){// esta condicional nos dice que cuando el la primera parte del firework llega a 0 puede estallar
            this.explo = true ;
            this.explode();
            } 
        }
        // si es verdadero con este for creamos y almacenamos en el arry la explocion podemos mostrar cuando estalla el firework
        for (var i = this.parti.length-1; i >= 0 ;i--){
             this.parti[i].applyForce(gravity);// aplicamos la gravedad 
             this.parti[i].update();
             if(this.parti[i].done()){ // funcion que se crea para identificar si ha explotado 
                this.parti.splice(i,1); // elimnina el firework para darle lugar a otro nuevo 
             }
        }
    }
    //crea las particulas de la explocion
    this.explode = function(){
        for (var i = 0; i<= 100;i++){
            var p = new Particles(this.firework.pos.x,this.firework.pos.y,this.col,false);
            this.parti.push(p);
            
        }
        
    }
    // propiedad de mostrar el extallido
    this.show = function(){
         if(!this.explo){
        this.firework.show();
         }
        for (var i = 0; i < this.parti.length ;i++){
             this.parti[i].show();
            
        }
    }
}
    
}