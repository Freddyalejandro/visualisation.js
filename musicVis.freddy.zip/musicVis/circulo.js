/*esta visualizacion mostrara dos semicirculos que seran como dos sole que crearan pequenas estrellas de colores 
el fourier lo aplique en tres partes uno para mover los semicirculos, para que las pequenas estrellas sean explulsadas con
fuerza dependiendo de la fuera del sonido, y tren con el bit mas fuera tambiem podemos notar que la 
imagen de la tirra puede temblar  */

function Circulo() {
	this.name = "Circulo";//nombre del visualizador
    var part = [];//array donde almacenar las particulas
    this.img = loadImage('imagenes/tierrapng.png')// imagen de la tierra 
	//draw the wave form to the screen

	this.draw = function() {
        
		push();
        angleMode(DEGREES)// para poder gener la curba en la ola
        fourier.analyze()
        rf = fourier.getEnergy(20,200)

        /*desde que puedo contrlar la imagen su tamana y movimiento*/
        push();
        // si la condicion se cumple la img tendra una pequena rotacion 
        if(rf >190){
            rotate(random(-0.5,0.5))
        }
        image(this.img,width/2-160,height/2-100,200,180)
        // este pop me ayuda a separar es movimiento exclusivo de la img 
        pop();

        // primera ola
        var wave = fourier.waveform();
        push();
        translate(width+5, height+5);// mover ola en la parte inferior de la pantalla 
        //comenzar la figuera 
        beginShape();
            stroke([random(0,255),random(0,255),random(0,255)]);// asignar color random 
            strokeWeight(3);
            noFill();
            // genera la curva con 360grados,
            for(var i = 0; i <=360 ;i+= 0.5){

                // la posicion la ola
                var index = floor(map(i,0,360,0,wave.length-1));
                // tamana del radio de la circunferencia
                var r = map(wave[index],-1,1,150,350);
                // usando x y junto con el radio, hacemos la curba aplicando sin  y cos 
                var x = r * sin(i);
                var y = r * cos(i);
                // junto con esta funcion terminamos el preoceso de curbatura 
                vertex(x, y);
            }
        //terminamos la figura 
        endShape();
        // usamos el constructor y creamos las particulas, almacenamos en el array part
        var nPart = new Starts();
        part.push(nPart);
        // loop que nos ayuda almacenar y usar las propiedades de starts para crear la lluvia de estrellas
            for(var i = part.length - 1; i >= 0;i--){
            // si la condicion se cumple creara la lluvia de estrellas, con sus propiedades
            if(!part[i].edges()){
                part[i].update(rf > 170)//cuando hace update si el ritmo es mayor a 170 movera las estrellas con la condicion;
                part[i].show();// creacion de una estrella.
            }else{
                part.splice(i,1)//eliminara las estrellas una por una
            }    
        }
        pop();

        /* creacion de la segunda ola
        **********es el mismo proceso para las dos olas**********
        */
        var wave2 = fourier.waveform();
        beginShape();
        stroke([random(0,255),random(0,255),random(0,255)])
        strokeWeight(3);
        noFill();
        for(var i = 0; i <=180 ;i+= 0.5){
            var index = floor(map(i,0,180,0,wave2.length - 1))
            var r = map(wave2[index],-1,1,150,350)
            var x = r * sin(i) 
            var y = r * cos(i)    
            vertex(x, y);
            }
        endShape(); 
		var nPart2 = new Starts();
        part.push(nPart2);
            for(var i = part.length - 1; i >= 0;i--){
            if(!part[i].edges()){
              part[i].update(rf > 170);
              part[i].show();
            }else{
                part.splice(i,1);
                }    
            }         
	};
    //clase start con las propiedades de constructor,update,edges  y show
    class Starts{
        //propiedad de constructor 
        constructor() {
            //posicion alcrear las part
            this.pos = p5.Vector.random2D().mult(250);
            //velocidad
            this.velo = createVector(0 ,0)
            //aceleracion, condicion de fourier para que las particulas sean lentas si no hay sonido
            if(rf < 2){
                this.acele = this.pos.copy().mult(random(0.000001,0.000001))
            }else{
                this.acele = this.pos.copy().mult(random(0.00001,0.00001))
            }
            //tamano
            this.tama = random(3, 5)
            //color
            this.color = [random(0,255),random(0,255),random(0,255)]
            
        }// propiedad de update que resibe un parametro(condicon fourier < 170)
        update(condi){
            this.velo.add(this.acele);// a la velocidad le agregamos acelaracion
            this.pos.add(this.velo);// a la posicion le agregamos velocidad
            if(condi){
                /* si la condicion se cumple multiplicamos por tres la posicion add velo hace el efecto
                 de estrellas mas rapidas que otras,*/
                this.pos.add(this.velo);
                this.pos.add(this.velo);
                this.pos.add(this.velo);    
            }
        }
        /*edges me ayuda a elmiminar las Starts y crearlas de nuevo si cumple la condicon
         de ser mayor de el tamana de la pantalla */
        edges(){
            if(this.pos.x < -width || this.pos.x > width  || this.pos.y < -width || this.pos.y > width ){
                return true;
            }else{
                return false;
            }
        }
        // propiedad que muestra el color, y la posicion y el tamano de las part 
        show(){
            noStroke();
            fill(this.color);//usando la propiedad de color
            ellipse(this.pos.x, this.pos.y, this.tama+2,5,20)
            //con la posicion x y y el tamana que llega de la propiedad,

        }
        
    }
}
 